let Celcius = parseFloat(10);
let Fahrenheit = parseFloat(50);

function convertFahrenheitToCelsius (ftemp){
    return  (ftemp - 32) / 1.8;
}


console.log(convertFahrenheitToCelsius(71).toFixed(2));



