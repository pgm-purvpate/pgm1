function removeTheVowels(str){
    return str.replace(/[aeiou]/gi, '');
}

console.log(removeTheVowels("JavaScript"));