function getPersonalMessage(name) {
    return `Greetings ${name} you will be a great developer :)`; // return message
}

console.log(getPersonalMessage("Dion"));// Log return value, call function, arg 1 is name