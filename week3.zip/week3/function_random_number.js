function getRandomNumber() {
    return Math.random();// Return Random number
} 

console.log(getRandomNumber()); // log message, call function