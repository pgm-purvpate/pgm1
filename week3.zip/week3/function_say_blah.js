function sayBlah(){
    console.log(
    `
    Zack: Check it out, all about planets this month.

    Leonard: That’s an atom.

    Zack: Agree to disagree. That’s what I love about science, there’s no one right answer.

    Leonard: So, you and Zack again, huh?

    Penny: Yeah, yeah, me and Zack again.
    `
    );
}

sayBlah();