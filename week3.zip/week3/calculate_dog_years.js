function calculateDogYears(human_years) {
    return `Your dog is ${human_years/7} years old in dog years!`; // divide human years / 1 dog year
}


console.log(calculateDogYears(105)); //log in dog years
