function sayHello(){
    return "Hello World"; // return Hello World
}

console.log(sayHello()); // Log return value, call function