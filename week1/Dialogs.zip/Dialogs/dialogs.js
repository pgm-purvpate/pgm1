console.log("test");


const age = prompt("What is your age");
console.log(age);