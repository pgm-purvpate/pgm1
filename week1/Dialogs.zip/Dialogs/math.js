const a = 14;


a++;
console.log(a); // 15
a--;
console.log(a); // 14

let a1 = 10;
console.log(++a1); //11
let a2 = 10; 
console.log(a2++); //10 ! FOUT